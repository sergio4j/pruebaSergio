<?php
//BORRAR LA TABLA AL BORRAR PLUGIN
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit();
}

global $wpdb;
$table_name = $wpdb->prefix . 'bluecell_form';
$wpdb->query("DROP TABLE IF EXISTS $table_name");